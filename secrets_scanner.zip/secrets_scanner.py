import argparse
import logging
import os
import re
import sys
from typing import List, Tuple, Pattern

# Configure logging
logger = logging.getLogger("secrets_scanner")
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
logger.addHandler(handler)

# Regex patterns to detect
PATTERNS: List[Tuple[str, Pattern, str]] = [
    ("AWS Access Key ID", re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "AWS Access Key ID (AKIA...)"),

    ("AWS Secret Access Key", re.compile(r"(?i)(?:aws|secret|aws_secret_access_key|aws_secret|awssecret).{0,40}?['\"][0-9a-zA-Z/+=]{40}['\"]"), "AWS secret key (40 chars)"),

    ("Google API Key", re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), "Google API key (AIza...)"),

    ("GitHub Token (ghp/gho/ghs)", re.compile(r"\bgh[pousr]_[0-9A-Za-z]{36}\b"), "GitHub personal/access token (ghp_...)"),

    ("Slack Token", re.compile(r"\bxox[baprs]-?[0-9A-Za-z-]{10,48}\b"), "Slack token (xoxb/xoxp/xoxa...)"),

    ("Stripe Secret Key", re.compile(r"\bsk_(live|test)_[0-9a-zA-Z]{24}\b"), "Stripe secret key (sk_live_... / sk_test_...)"),

    ("Private Key Block", re.compile(r"-----BEGIN (?:RSA|DSA|EC|OPENSSH|PRIVATE) PRIVATE KEY-----", re.IGNORECASE), "Private key PEM header"),

    ("High-entropy token (base64-like)", re.compile(r"\b[A-Za-z0-9+/]{30,}={0,2}\b"), "Long base64-like token (possible secret)"),

    ("Password Assignment", re.compile(r"(?i)\b(password|passwd|pwd|secret)\b\s*[:=]\s*['\"][^'\"]{6,200}['\"]"), "Common password variable assignment"),
]

# File extentions to skip
SKIP_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".exe", ".dll", ".so", ".class", ".pyc", ".zip", ".tar", ".gz"
}

def is_text_file(filepath: str) -> bool:
    _, ext = os.path.splitext(filepath)
    if ext.lower() in SKIP_EXTENSIONS:
        return False
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(1024)
            if b"\0" in chunk:
                return False
    except Exception:
        return False
    return True

def scan_file(filepath: str, patterns: List[Tuple[str, Pattern, str]], min_length: int = 0) -> List[Tuple[str,int,str,str]]:
    findings = []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as fh:
            for lineno, line in enumerate(fh, start=1):
                for name, regex, _desc in patterns:
                    for m in regex.finditer(line):
                        matched = m.group(0)
                        if len(matched) < min_length:
                            continue
                        snippet = line.strip()
                        if len(snippet) > 240:
                            snippet = snippet[:120] + " ... " + snippet[-120:]
                        findings.append((name, lineno, matched, snippet))
    except Exception as e:
        logger.debug(f"Could not read {filepath}: {e}")
    return findings

def scan_path(path: str, patterns: List[Tuple[str, Pattern, str]], min_length: int = 0) -> List[Tuple[str,str,int,str,str]]:
    results = []
    if os.path.isfile(path):
        if is_text_file(path):
            file_findings = scan_file(path, patterns, min_length)
            for name, lineno, matched, snippet in file_findings:
                results.append((path, name, lineno, matched, snippet))
        else:
            logger.debug(f"Skipping non-text file: {path}")
    else:
        for root, dirs, files in os.walk(path):
            for fname in files:
                fpath = os.path.join(root, fname)
                if not is_text_file(fpath):
                    continue
                file_findings = scan_file(fpath, patterns, min_length)
                for name, lineno, matched, snippet in file_findings:
                    results.append((fpath, name, lineno, matched, snippet))
    return results

# Main
def parse_args():
    p = argparse.ArgumentParser(
        description="Scan files or directories for common hardcoded secret patterns."
    )
    p.add_argument("path", help="File or directory to scan")
    p.add_argument("--report", "-r", help="Write findings to a report file (plain text). If omitted, prints to stdout")
    p.add_argument("--min-length", "-m", type=int, default=1, help="Minimum matched-string length to report (default: 1)")
    p.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")
    p.add_argument("--list-patterns", action="store_true", help="List built-in patterns and exit")
    return p.parse_args()

def main():
    args = parse_args()
    if args.verbose:
        logger.setLevel(logging.DEBUG)
        logger.debug("Verbose logging enabled")

    if args.list_patterns:
        print("Built-in detection patterns:")
        for name, regex, desc in PATTERNS:
            print(f"- {name}: /{regex.pattern}/  -- {desc}")
        sys.exit(0)

    target = args.path
    if not os.path.exists(target):
        logger.error(f"Path does not exist: {target}")
        sys.exit(2)

    logger.info(f"Scanning: {target}")
    findings = scan_path(target, PATTERNS, min_length=args.min_length)

    if not findings:
        logger.info("No potential secrets found.")
    else:
        logger.info(f"Found {len(findings)} potential secret(s).")
        lines = []
        header = "file\tpattern\tline\tmatch\tcontext"
        lines.append(header)
        for fpath, pname, lineno, match_text, snippet in findings:
            lines.append(f"{fpath}\t{pname}\t{lineno}\t{match_text}\t{snippet}")

        output = "\n".join(lines)
        if args.report:
            try:
                with open(args.report, "w", encoding="utf-8") as of:
                    of.write(output)
                logger.info(f"Report written to: {args.report}")
            except Exception as e:
                logger.error(f"Could not write report: {e}")
                print(output)
        else:
            print(output)

if __name__ == "__main__":
    main()
